<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'blogskeleton-2.0-pl/setup-options.php',
    'enduser_option_merge' => 'yes',
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => 'yes',
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b453b967d4660b90970c63f95b85cdb5',
      'native_key' => 'b453b967d4660b90970c63f95b85cdb5',
      'filename' => 'xPDOFileVehicle/7c2ee0e1e02daeb5204414105aca7e37.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb3f55dd4a46e91e5a11acb2a15aa38',
      'native_key' => 'extension_packages',
      'filename' => 'modSystemSetting/62332a47e5fb82a13d0927f05c4adb9d.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '604e42d0e9580b54677dfa08deb88d90',
      'native_key' => 54,
      'filename' => 'modChunk/51562e66e26e9e869a7a1e5c4b4487e4.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '20672aaa10840fa8d3e611bb8b7fc5c7',
      'native_key' => 56,
      'filename' => 'modChunk/9872d5ee2f93cf9f5f99a57c3d162e2f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd809022771103789973dfbbf219e8ffd',
      'native_key' => 57,
      'filename' => 'modChunk/6fec1ca57c95643c58fb622f8641bc47.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'eeb19eb80a0cf388ffc4e68ebd0f6385',
      'native_key' => 58,
      'filename' => 'modChunk/e1749f6481ffa2673abb33b022010325.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9c00bae60a5a9bdd65fd7e9db0dcff42',
      'native_key' => 55,
      'filename' => 'modChunk/20267eda183dfae272306bd2b1f5c1b2.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9abec91f3147a1c6b124aae8eb3f39b5',
      'native_key' => 59,
      'filename' => 'modChunk/e8699687ff4dac3c7544f61cce10b878.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '29174670863f252da450e7d1f66402d9',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'category_id',
      ),
      'filename' => 'modContextSetting/364460f5a646a6d97854da606b6b5983.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '7eb6f1865ad14ff6924f5f9e4a4aa94e',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'blog_id',
      ),
      'filename' => 'modContextSetting/d8f872ca40a0397011e26438f77e2a1f.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2326c6399789e14afeced4b3884b883b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'archive_id',
      ),
      'filename' => 'modContextSetting/5fef7c4f26dd7e3e76aa3ab588e093f7.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'deb7a28a758a56423bd28e14783c63ef',
      'native_key' => 29,
      'filename' => 'modDocument/f583148f9a62fba6e9e41fc4d6c4a779.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'CollectionContainer',
      'guid' => 'dc83479ccbf4a9d53c9a9c1277711d0e',
      'native_key' => 6,
      'filename' => 'CollectionContainer/b923b36639a385729eb63145fe804446.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'fe47b73df9c3384dd5c003f78f1567c6',
      'native_key' => 11,
      'filename' => 'modDocument/a9acb01057f2a11a94e77edc9cb8f074.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'f07c06cd0d0f9fb49d3a52d7e1dbba76',
      'native_key' => 12,
      'filename' => 'modDocument/6cc54f0c65cd684d8d741138ec5f0fde.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '3f346dfa8ce4893669f55e90c23b53ca',
      'native_key' => 17,
      'filename' => 'modDocument/737843b14471440fe151090f281c466d.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'e00133ab8e45802f79e7577d84d9f799',
      'native_key' => 19,
      'filename' => 'modDocument/cc813e52b4fd2915af0ee99709989884.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '67c63be6fa9da082449271d2a542a679',
      'native_key' => 22,
      'filename' => 'modDocument/c5016849f2a28b5a7aeef5932fc2691f.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '953737ecf681dc77901ce90f39fdfc24',
      'native_key' => 8,
      'filename' => 'modSnippet/3bf724de15f3b0df8d46a749f9aacee5.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '9e09564fe390994a82f0f2ee621cc564',
      'native_key' => 1,
      'filename' => 'modTemplate/c56753e5b4d529f61576accfe7721e1a.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'bcfeef48cffd4def5d32dfa455ba63b2',
      'native_key' => 2,
      'filename' => 'modTemplate/d889f2b5d2194ae7dbb58e1fbc8f321f.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '4aef3e756aa4264fe6550f7b7b288a85',
      'native_key' => 3,
      'filename' => 'modTemplate/b176d02af435342fef8bf8f0056b9897.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '22068b2609d10d75c6784c68f33fdc08',
      'native_key' => 4,
      'filename' => 'modTemplate/710b9604a6c53e66b8eccb7dbbb14acf.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '3460a8d6875a5885558db2fa2e46019f',
      'native_key' => '3460a8d6875a5885558db2fa2e46019f',
      'filename' => 'xPDOScriptVehicle/5d42afd609a2734abf11e3c78abdf9ec.vehicle',
    ),
  ),
);