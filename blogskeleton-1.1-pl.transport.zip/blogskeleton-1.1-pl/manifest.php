<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'blogskeleton-1.1-pl/setup-options.php',
    'enduser_option_merge' => 'yes',
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => 'yes',
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f49e06f717f6872406e7ae5e78bf2863',
      'native_key' => 'f49e06f717f6872406e7ae5e78bf2863',
      'filename' => 'xPDOFileVehicle/66040b15b87084320168d92102edf2a8.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4b6b6423570b92e6c09ae22fed4a634',
      'native_key' => 'extension_packages',
      'filename' => 'modSystemSetting/e9593c6af01690a4da35e04bd7c1f5fb.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd153dea91ab08cf56d99d4ece4fe6d6a',
      'native_key' => 54,
      'filename' => 'modChunk/a8bb67db590d7adc7a9fc5c59ff60564.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '5eecc3e4c131a370b870d5a00e13554a',
      'native_key' => 55,
      'filename' => 'modChunk/4863e6fb86bb47897195d416ef997823.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e741751bc41b1a51e9472f0abfb877c0',
      'native_key' => 56,
      'filename' => 'modChunk/b36fbca91c0aa52d3d28030e05ef9020.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '885e0f2bc60758cf704e36efe90dfe4b',
      'native_key' => 57,
      'filename' => 'modChunk/6b5d58042ff6dd17952031bb0a9a62c1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '383e84b2a2f8f88889174e760106cd8d',
      'native_key' => 58,
      'filename' => 'modChunk/cdd228503b796e894d5a08667718552b.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e713dda4d86ff9d461b5f95954f460b7',
      'native_key' => 59,
      'filename' => 'modChunk/8fc2b1990448c8f58781a1793cf3aec4.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd4869536a68b44ba9cc8d6c9e730bbc3',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'category_id',
      ),
      'filename' => 'modContextSetting/7d3a9cbe5ecad71478d6d16c58ef4d5e.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6e07d36765d1faae836e960c4451add3',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'blog_id',
      ),
      'filename' => 'modContextSetting/8eedd5870c6f82255c574f44711f6ecf.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'fe62a8a34cfee52dfbfd603ce040fe07',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'archive_id',
      ),
      'filename' => 'modContextSetting/c14ea8e48dd7a3fe9128137e9c855b77.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '3c21be55eda9fa1815f2d32f67e9049f',
      'native_key' => 29,
      'filename' => 'modDocument/33830d1158a6531128fe505857449d0c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'CollectionContainer',
      'guid' => '2a9ad163470ee401febf430cad331295',
      'native_key' => 6,
      'filename' => 'CollectionContainer/043eddac6ce512588457ddb380f4d9d8.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'e99fa355f51e8f9834d290327e260d40',
      'native_key' => 11,
      'filename' => 'modDocument/4143d8d09481bd712e2b97c949f851d9.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '156d4147c0ce3da544d3a7baf6f90602',
      'native_key' => 12,
      'filename' => 'modDocument/b77c1173ae366c271e210b1c616d161a.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '92d616ded859531fcb60fd1c86284c04',
      'native_key' => 17,
      'filename' => 'modDocument/f92a1c89b7519127926a91712e7562ec.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'f61eb8f32e4bbc74741e45303c973dc8',
      'native_key' => 19,
      'filename' => 'modDocument/c400fc77be9bd56142ba23b3a4ad1358.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '8a620d89cc0d64163d76b265e3b78b22',
      'native_key' => 22,
      'filename' => 'modDocument/124bba2d065d68b3233d6ed84e38e2a6.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'bf1804499c84d6feec386508cc5cb37a',
      'native_key' => 8,
      'filename' => 'modSnippet/54fe11dffc2cbde8ebffca4db8a76659.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '62c96a79b88cfc14c37729e56af00fb2',
      'native_key' => 1,
      'filename' => 'modTemplate/18a867efb465fd262e18d56698d8f87f.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '803aa795c91d57bf2f54dd16aeacab2b',
      'native_key' => 2,
      'filename' => 'modTemplate/1769be3cb2bf64e82a4841fee3b3b5a0.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '70b3f2b763244658bf489f306055434f',
      'native_key' => 3,
      'filename' => 'modTemplate/b02c9428538590bc0aab135d6b4122bc.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'c46dddd6b1d299a6593cfb006a249df8',
      'native_key' => 4,
      'filename' => 'modTemplate/19383881b792f689ad4a053d07772516.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '8598ac20298923a150b2d166789e00a2',
      'native_key' => '8598ac20298923a150b2d166789e00a2',
      'filename' => 'xPDOScriptVehicle/a6a280915710671d4d5faf2289ae3b49.vehicle',
    ),
  ),
);