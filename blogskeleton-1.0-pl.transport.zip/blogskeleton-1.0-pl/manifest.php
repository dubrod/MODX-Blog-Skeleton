<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'blogskeleton-1.0-pl/setup-options.php',
    'enduser_option_merge' => 'yes',
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => 'yes',
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '774ed8c3833d718188848fb9e5636a16',
      'native_key' => '774ed8c3833d718188848fb9e5636a16',
      'filename' => 'xPDOFileVehicle/2925026b075fa6f78cd9797fc9a97322.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2cc10b23b34fdb4066cd2414b9a69c3',
      'native_key' => 'extension_packages',
      'filename' => 'modSystemSetting/5bfd403962cf007965599c617ee2f9d6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e9e723a519d6099456b8ffe741a0a6b4',
      'native_key' => 54,
      'filename' => 'modChunk/6b42a1aca15dd4aea1f1e1efdcbfd06b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '2c7d791456755cdd58052c3e0a150447',
      'native_key' => 55,
      'filename' => 'modChunk/6d5b2821be61c05c9436bed0c7808385.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '80fa12cb5b6657e5aafc243e045c1ef4',
      'native_key' => 56,
      'filename' => 'modChunk/3c04da1b7344a421b0fc16aebd9c239d.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '87c047852ccd07c12fdc0d9a04eb68dc',
      'native_key' => 57,
      'filename' => 'modChunk/8c05d621ec4a84cc9682304dbf44ec16.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e10562f4df20b5630da0c94643280a71',
      'native_key' => 58,
      'filename' => 'modChunk/8ea403ca9c440aa8ec153611fdd8cfd5.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '3adea1c733478aed907fca6e2f0ce27e',
      'native_key' => 59,
      'filename' => 'modChunk/fa9b832f46186538564a1e491eaf46c5.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'fbbb678bdca367962967918dadb50786',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'category_id',
      ),
      'filename' => 'modContextSetting/6d03288e099bd0e83b5a7ae8ffd3ff1b.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '08e36c388019dffd5ed51ea04f6bbc4b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'blog_id',
      ),
      'filename' => 'modContextSetting/40a6a09b43491d1a20e5336fb4d5cedb.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'cddb846868ad69b5b286bd672912ffe4',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'archive_id',
      ),
      'filename' => 'modContextSetting/5e929a64d98d488500d1e342356581a1.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '782d899eec576f833ca9be65f0d4672c',
      'native_key' => 29,
      'filename' => 'modDocument/d70786ecb7bf14c51d38097edfb552bb.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'CollectionContainer',
      'guid' => '598946415523f369bf22a7ebef668e50',
      'native_key' => 6,
      'filename' => 'CollectionContainer/4eb8eaa7aae5893aa3df59aade039e82.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '7fc9fdc9c2943f8931cc10922f358d45',
      'native_key' => 11,
      'filename' => 'modDocument/2a78e2e8b6163b5aa58c791be095d06d.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '30f31b1cd48022309fdebb8b46c0b811',
      'native_key' => 12,
      'filename' => 'modDocument/0daf5873624c9d121c1f63d039a5940f.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '335547f8eb4687d2eced5d4e6c60adf6',
      'native_key' => 17,
      'filename' => 'modDocument/1b35cf696a8b9d495e2e6e1b028c6540.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'b4110bd6fbcc3a752c7a317ae1790b8f',
      'native_key' => 19,
      'filename' => 'modDocument/84b4ebe2b48f6ab1fa9cd945c10a4c51.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'f9bd4a248bfe947a757ebe0a9ad1dd92',
      'native_key' => 22,
      'filename' => 'modDocument/32f8f46ad8b343204dfa0966e523e99d.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '8ec0384266c23827df9ef74933796b1d',
      'native_key' => 8,
      'filename' => 'modSnippet/0279d67d8d71b6b6c6ee7d9fa2a21545.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '249450b8459cd8471c4315b652b91dae',
      'native_key' => 1,
      'filename' => 'modTemplate/2e281bc3e16f6001bc314a9fd96c47fe.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '4cc3bf054aa1dad0eeb4475aafdd1af2',
      'native_key' => 2,
      'filename' => 'modTemplate/d4a2c31f941c38d75dd8452ec2b66ec7.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '48bc1ab1b5b9612b1c35e17109334612',
      'native_key' => 3,
      'filename' => 'modTemplate/d8ec9e2f5feea15db9d77c274a108f65.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '622532f89e90ba664791361c6fc2d6fa',
      'native_key' => 4,
      'filename' => 'modTemplate/1a5a1c876e6dd05aa7588a220b36f377.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'caafebaba648596c28ea53f856626e0c',
      'native_key' => 'caafebaba648596c28ea53f856626e0c',
      'filename' => 'xPDOScriptVehicle/5591cc9414b51442ec4e4e8438ac1e28.vehicle',
    ),
  ),
);